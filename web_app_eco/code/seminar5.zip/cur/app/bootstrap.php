<?php

use App\Application;

require __DIR__.'/../vendor/autoload.php';

return new Application(dirname(__DIR__));